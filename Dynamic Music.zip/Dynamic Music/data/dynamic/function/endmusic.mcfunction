# Stops the music before playing
execute as @a at @s run stopsound @s * moremusic:end_boss

# Plays the music
execute as @a at @s run playsound moremusic:end_boss weather @s

# Removes the tag so it can be reset with the reset function 
tag @s remove hasRunOnce

# Loops back the music
schedule function dynamic:endmusic 231s replace