# Initializes hasRunOnce tag
# Every player has once, once a condition is met, it removes the tag so it can play the music
tag @s add hasRunOnce