# Stops the music before playing
execute as @a at @s run stopsound @s * moremusic:nether_boss

# Plays the music
execute as @a at @s run playsound moremusic:nether_boss weather @s

#Debugging
#execute as @a at @s run say "I ran as a player"

# Removes the tag so it can be reset with the reset function
tag @s remove hasRunOnce

# Loops back the music
schedule function dynamic:nethermusic 122s replace