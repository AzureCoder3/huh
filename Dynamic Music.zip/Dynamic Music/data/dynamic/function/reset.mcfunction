stopsound @s * moremusic:nether_boss
stopsound @s * moremusic:end_boss
schedule clear dynamic:nethermusic
schedule clear dynamic:endmusic

# Readds the tag so it can trigger once more
tag @s add hasRunOnce
