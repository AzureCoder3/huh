execute as @a[tag=hasRunOnce] at @s if dimension minecraft:the_nether run function dynamic:nethermusic
execute as @a[tag=hasRunOnce] at @s if dimension minecraft:the_end run function dynamic:endmusic

execute as @a[tag=!hasRunOnce] at @s if dimension minecraft:overworld run function dynamic:reset
execute as @a[tag=!hasRunOnce] at @s if dimension minecraft:overworld run say "Reseting"